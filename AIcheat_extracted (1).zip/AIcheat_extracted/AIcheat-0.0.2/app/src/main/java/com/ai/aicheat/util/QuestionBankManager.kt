package com.ai.aicheat.util

import android.content.Context
import android.util.Log
import com.ai.aicheat.App
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.InputStreamReader

/**
 * 题库管理器
 * 负责读取、解析和管理本地题库
 */
object QuestionBankManager {
    
    private const val TAG = "QuestionBankManager"
    
    // 题库配置键
    private const val KEY_QUESTION_BANK_PATH = "question_bank_path"
    private const val KEY_QUESTION_BANK_ENABLED = "question_bank_enabled"
    
    private val prefs by lazy {
        App.instance.getSharedPreferences("aicheat_config", Context.MODE_PRIVATE)
    }
    
    // 题库路径
    var questionBankPath: String
        get() = prefs.getString(KEY_QUESTION_BANK_PATH, "") ?: ""
        set(value) = prefs.edit().putString(KEY_QUESTION_BANK_PATH, value).apply()
    
    // 是否启用本地题库
    var isQuestionBankEnabled: Boolean
        get() = prefs.getBoolean(KEY_QUESTION_BANK_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_QUESTION_BANK_ENABLED, value).apply()
    
    // 已加载的题库数据
    private var questionCache: MutableList<Question> = mutableListOf()
    
    /**
     * 题目数据类
     */
    data class Question(
        val id: String,
        val chapter: String,        // 章节
        val type: String,           // 题目类型：single_choice, multiple_choice, fill_blank, essay
        val content: String,        // 题干
        val options: List<String>,  // 选项（选择题有）
        val answer: String,         // 答案
        val explanation: String = "" // 解析（可选）
    )
    
    /**
     * 搜索结果
     */
    data class SearchResult(
        val question: Question,
        val matchScore: Float,      // 匹配分数（0-1）
        val matchedKeywords: List<String> // 匹配的关键词
    )
    
    /**
     * 加载题库
     * @param path 题库文件夹路径
     * @return 加载结果
     */
    fun loadQuestionBank(path: String): Result<Int> {
        return try {
            Log.d(TAG, "开始加载题库: $path")
            questionCache.clear()
            
            val directory = File(path)
            if (!directory.exists() || !directory.isDirectory) {
                Log.e(TAG, "题库目录不存在: $path")
                return Result.failure(Exception("题库目录不存在"))
            }
            
            var totalQuestions = 0
            
            // 遍历目录下所有文件
            directory.listFiles()?.forEach { file ->
                if (file.isFile && (file.name.endsWith(".json") || file.name.endsWith(".txt"))) {
                    val count = loadQuestionFile(file)
                    totalQuestions += count
                    Log.d(TAG, "加载文件 ${file.name}: $count 道题目")
                }
            }
            
            // 同时加载 assets 中的默认题库
            loadDefaultQuestionBank()
            
            Log.d(TAG, "题库加载完成，共 ${questionCache.size} 道题目")
            questionBankPath = path
            isQuestionBankEnabled = true
            Result.success(questionCache.size)
        } catch (e: Exception) {
            Log.e(TAG, "加载题库失败", e)
            Result.failure(e)
        }
    }
    
    /**
     * 加载默认题库（从 assets）
     */
    private fun loadDefaultQuestionBank() {
        try {
            val assetFiles = App.instance.assets.list("question_bank") ?: return
            
            assetFiles.forEach { fileName ->
                try {
                    val inputStream = App.instance.assets.open("question_bank/$fileName")
                    val jsonString = inputStream.bufferedReader().use { it.readText() }
                    parseQuestionJson(jsonString, "默认题库")
                    inputStream.close()
                    Log.d(TAG, "加载 assets 题库: $fileName")
                } catch (e: Exception) {
                    Log.w(TAG, "加载 assets 文件失败: $fileName")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "加载默认题库失败", e)
        }
    }
    
    /**
     * 加载单个题库文件
     */
    private fun loadQuestionFile(file: File): Int {
        return try {
            val jsonString = FileInputStream(file).use { inputStream ->
                InputStreamReader(inputStream).use { reader ->
                    reader.readText()
                }
            }
            val chapterName = file.nameWithoutExtension
            parseQuestionJson(jsonString, chapterName)
        } catch (e: Exception) {
            Log.e(TAG, "加载题库文件失败: ${file.name}", e)
            0
        }
    }
    
    /**
     * 解析 JSON 格式题库
     */
    private fun parseQuestionJson(jsonString: String, chapter: String) {
        try {
            val jsonArray = JSONArray(jsonString)
            for (i in 0 until jsonArray.length()) {
                val questionJson = jsonArray.getJSONObject(i)
                
                val question = Question(
                    id = questionJson.optString("id", "${chapter}_$i"),
                    chapter = chapter,
                    type = questionJson.optString("type", "single_choice"),
                    content = questionJson.optString("content", ""),
                    options = parseOptions(questionJson.optJSONArray("options")),
                    answer = questionJson.optString("answer", ""),
                    explanation = questionJson.optString("explanation", "")
                )
                
                if (question.content.isNotBlank()) {
                    questionCache.add(question)
                }
            }
        } catch (e: Exception) {
            // 尝试解析文本格式
            parseTextFormat(jsonString, chapter)
        }
    }
    
    /**
     * 解析选项数组
     */
    private fun parseOptions(optionsArray: JSONArray?): List<String> {
        if (optionsArray == null) return emptyList()
        
        val options = mutableListOf<String>()
        for (i in 0 until optionsArray.length()) {
            options.add(optionsArray.getString(i))
        }
        return options
    }
    
    /**
     * 解析文本格式题库
     * 格式：1.题干\nA.选项1\nB.选项2\n答案: A
     */
    private fun parseTextFormat(content: String, chapter: String) {
        val lines = content.lines()
        var currentQuestion: Question? = null
        val options = mutableListOf<String>()
        
        lines.forEach { line ->
            val trimmedLine = line.trim()
            
            when {
                // 题号开头的新题
                Regex("^\\d+[.、]").containsMatchIn(trimmedLine) -> {
                    // 保存上一题
                    currentQuestion?.let {
                        if (it.content.isNotBlank()) {
                            questionCache.add(it.copy(options = options.toList()))
                        }
                    }
                    
                    options.clear()
                    
                    // 提取题干（去掉题号）
                    val questionContent = trimmedLine.replace(Regex("^\\d+[.、]"), "").trim()
                    currentQuestion = Question(
                        id = "${chapter}_${questionCache.size}",
                        chapter = chapter,
                        type = "single_choice",
                        content = questionContent,
                        options = emptyList(),
                        answer = ""
                    )
                }
                // 选项（A. B. C. D.）
                trimmedLine.matches(Regex("^[A-D][.、].*")) -> {
                    val option = trimmedLine.replace(Regex("^[A-D][.、]"), "").trim()
                    if (currentQuestion != null) {
                        options.add(option)
                    }
                }
                // 答案
                trimmedLine.startsWith("答案:") || trimmedLine.startsWith("答案：") -> {
                    val answer = trimmedLine.replace(Regex("^答案[：:]"), "").trim()
                    currentQuestion?.let {
                        currentQuestion = it.copy(answer = answer)
                    }
                }
                // 续行内容
                trimmedLine.isNotEmpty() && currentQuestion != null -> {
                    currentQuestion = currentQuestion?.copy(
                        content = currentQuestion!!.content + " " + trimmedLine
                    )
                }
            }
        }
        
        // 保存最后一题
        currentQuestion?.let {
            if (it.content.isNotBlank()) {
                questionCache.add(it.copy(options = options.toList()))
            }
        }
    }
    
    /**
     * 搜索题目
     * @param query 搜索关键词
     * @param limit 返回结果数量限制
     * @return 匹配的题目列表
     */
    fun searchQuestions(query: String, limit: Int = 5): List<SearchResult> {
        if (questionCache.isEmpty() || query.isBlank()) {
            return emptyList()
        }
        
        val keywords = extractKeywords(query)
        val results = mutableListOf<SearchResult>()
        
        questionCache.forEach { question ->
            val matchScore = calculateMatchScore(question, keywords)
            if (matchScore > 0.1f) { // 只返回匹配度超过10%的结果
                val matchedKeywords = keywords.filter { keyword ->
                    question.content.contains(keyword, ignoreCase = true) ||
                    question.options.any { it.contains(keyword, ignoreCase = true) }
                }
                results.add(SearchResult(question, matchScore, matchedKeywords))
            }
        }
        
        // 按匹配分数降序排序
        return results.sortedByDescending { it.matchScore }.take(limit)
    }
    
    /**
     * 从查询中提取关键词
     */
    private fun extractKeywords(query: String): List<String> {
        // 移除常见干扰词
        val stopWords = setOf(
            "的", "是", "什么", "哪个", "哪些", "如何", "怎样",
            "这道题", "这道", "这个", "请问", "帮我", "找一下",
            "选择", "填空", "答案", "题目"
        )
        
        return query
            .replace(Regex("[。，？！、]"), " ")
            .split(Regex("\\s+"))
            .filter { it.length >= 2 && it !in stopWords }
            .distinct()
    }
    
    /**
     * 计算匹配分数
     */
    private fun calculateMatchScore(question: Question, keywords: List<String>): Float {
        if (keywords.isEmpty()) return 0f
        
        var totalScore = 0f
        val contentLower = question.content.lowercase()
        
        keywords.forEach { keyword ->
            val keywordLower = keyword.lowercase()
            
            // 精确匹配权重最高
            if (contentLower.contains(keywordLower)) {
                totalScore += 0.3f
                
                // 标题匹配加更多分
                if (question.content.startsWith(keyword)) {
                    totalScore += 0.2f
                }
            }
            
            // 选项匹配
            question.options.forEach { option ->
                if (option.contains(keywordLower, ignoreCase = true)) {
                    totalScore += 0.1f
                }
            }
            
            // 章节名匹配
            if (question.chapter.contains(keywordLower, ignoreCase = true)) {
                totalScore += 0.1f
            }
        }
        
        // 归一化分数
        return (totalScore / keywords.size).coerceIn(0f, 1f)
    }
    
    /**
     * 获取随机题目
     */
    fun getRandomQuestions(count: Int = 10): List<Question> {
        return questionCache.shuffled().take(count.coerceAtMost(questionCache.size))
    }
    
    /**
     * 获取指定章节的题目
     */
    fun getQuestionsByChapter(chapter: String): List<Question> {
        return questionCache.filter { 
            it.chapter.contains(chapter, ignoreCase = true) 
        }
    }
    
    /**
     * 获取题库统计信息
     */
    fun getStatistics(): QuestionBankStats {
        val chapterCount = questionCache.map { it.chapter }.distinct().size
        val typeCount = questionCache.groupBy { it.type }
        
        return QuestionBankStats(
            totalQuestions = questionCache.size,
            chapterCount = chapterCount,
            typeDistribution = typeCount.mapValues { it.value.size }
        )
    }
    
    /**
     * 题库统计信息
     */
    data class QuestionBankStats(
        val totalQuestions: Int,
        val chapterCount: Int,
        val typeDistribution: Map<String, Int>
    )
    
    /**
     * 清除题库缓存
     */
    fun clearCache() {
        questionCache.clear()
        isQuestionBankEnabled = false
        Log.d(TAG, "题库缓存已清除")
    }
    
    /**
     * 导出题库为 JSON 格式
     */
    fun exportToJson(): String {
        val jsonArray = JSONArray()
        questionCache.forEach { question ->
            val jsonObject = JSONObject().apply {
                put("id", question.id)
                put("chapter", question.chapter)
                put("type", question.type)
                put("content", question.content)
                put("options", JSONArray(question.options))
                put("answer", question.answer)
                put("explanation", question.explanation)
            }
            jsonArray.put(jsonObject)
        }
        return jsonArray.toString(2)
    }
}
