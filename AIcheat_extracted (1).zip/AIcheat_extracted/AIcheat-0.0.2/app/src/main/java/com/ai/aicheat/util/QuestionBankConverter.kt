package com.ai.aicheat.util

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * 题库格式转换工具
 * 支持将各种格式的题库转换为统一的 JSON 格式
 */
object QuestionBankConverter {
    
    private const val TAG = "QuestionBankConverter"
    
    /**
     * 转换 DOCX 解析后的文本为 JSON 题库格式
     * @param markdownContent DOCX 转换后的 Markdown 内容
     * @param chapterName 章节名称
     * @return JSON 格式的题库字符串
     */
    fun convertFromMarkdown(markdownContent: String, chapterName: String): String {
        val questions = mutableListOf<QuestionBankManager.Question>()
        val lines = markdownContent.lines()
        
        var currentType = "single_choice" // 当前题目类型
        var currentQuestion: QuestionBankManager.Question? = null
        val options = mutableListOf<String>()
        var questionNumber = 0
        
        for (line in lines) {
            val trimmedLine = line.trim()
            
            // 检测题目类型
            when {
                trimmedLine.contains("单项选择题") -> {
                    currentType = "single_choice"
                    continue
                }
                trimmedLine.contains("多项选择题") -> {
                    currentType = "multiple_choice"
                    continue
                }
                trimmedLine.contains("判断题") -> {
                    currentType = "true_false"
                    continue
                }
                trimmedLine.contains("填空题") -> {
                    currentType = "fill_blank"
                    continue
                }
                trimmedLine.contains("简答题") -> {
                    currentType = "essay"
                    continue
                }
            }
            
            // 检测新题目（以数字开头）
            val questionMatch = Regex("^(\\d+)[.、．](.+)$").find(trimmedLine)
            if (questionMatch != null) {
                // 保存上一题
                saveCurrentQuestion(currentQuestion, options, questions, chapterName, currentType)
                
                questionNumber++
                options.clear()
                currentQuestion = QuestionBankManager.Question(
                    id = "${chapterName}_q${questionNumber}",
                    chapter = chapterName,
                    type = currentType,
                    content = questionMatch.groupValues[2].trim(),
                    options = emptyList(),
                    answer = ""
                )
                continue
            }
            
            // 检测选项
            val optionMatch = Regex("^[A-Da-d][.、．)）](.+)$").find(trimmedLine)
            if (optionMatch != null && currentQuestion != null) {
                options.add(optionMatch.groupValues[1].trim())
                continue
            }
            
            // 检测答案行
            if (trimmedLine.startsWith("答案") || 
                trimmedLine.startsWith("参考答案") ||
                trimmedLine.matches(Regex("^[A-Da-d][.、．]?$"))) {
                currentQuestion?.let { q ->
                    val answer = extractAnswer(trimmedLine)
                    currentQuestion = q.copy(answer = answer)
                }
                continue
            }
            
            // 检测解析
            if (trimmedLine.startsWith("解析") || 
                trimmedLine.startsWith("说明") ||
                trimmedLine.startsWith("提示")) {
                currentQuestion?.let { q ->
                    val explanation = trimmedLine.replace(Regex("^(解析|说明|提示)[：:]?"), "").trim()
                    currentQuestion = q.copy(explanation = explanation)
                }
                continue
            }
            
            // 续行内容（属于当前题目）
            if (trimmedLine.isNotEmpty() && currentQuestion != null && 
                !trimmedLine.startsWith("A.") && !trimmedLine.startsWith("B.") &&
                !trimmedLine.startsWith("C.") && !trimmedLine.startsWith("D.")) {
                currentQuestion = currentQuestion?.copy(
                    content = currentQuestion!!.content + " " + trimmedLine
                )
            }
        }
        
        // 保存最后一题
        saveCurrentQuestion(currentQuestion, options, questions, chapterName, currentType)
        
        // 转换为 JSON
        return convertQuestionsToJson(questions)
    }
    
    /**
     * 保存当前题目到列表
     */
    private fun saveCurrentQuestion(
        question: QuestionBankManager.Question?,
        options: List<String>,
        questions: MutableList<QuestionBankManager.Question>,
        chapter: String,
        type: String
    ) {
        question?.let {
            if (it.content.isNotBlank()) {
                questions.add(it.copy(options = options))
            }
        }
    }
    
    /**
     * 提取答案
     */
    private fun extractAnswer(answerLine: String): String {
        // 格式: "答案: A" 或 "A" 或 "答案：A"
        val cleaned = answerLine
            .replace(Regex("^(答案|参考答案)[：:]?"), "")
            .replace(Regex("^[A-Da-d][.、．]?"), "")
            .trim()
        
        return cleaned.ifEmpty { answerLine.firstOrNull()?.uppercase() ?: "" }
    }
    
    /**
     * 将题目列表转换为 JSON 格式
     */
    private fun convertQuestionsToJson(questions: List<QuestionBankManager.Question>): String {
        val jsonArray = JSONArray()
        
        questions.forEach { question ->
            val jsonObject = JSONObject().apply {
                put("id", question.id)
                put("chapter", question.chapter)
                put("type", question.type)
                put("content", question.content)
                put("options", JSONArray(question.options))
                put("answer", question.answer)
                put("explanation", question.explanation)
            }
            jsonArray.put(jsonObject)
        }
        
        return jsonArray.toString(2)
    }
    
    /**
     * 从文本文件导入题库
     * @param filePath 文本文件路径
     * @param chapterName 章节名称
     * @return JSON 格式的题库字符串
     */
    fun importFromTextFile(filePath: String, chapterName: String): Result<String> {
        return try {
            val file = File(filePath)
            if (!file.exists()) {
                return Result.failure(Exception("文件不存在: $filePath"))
            }
            
            val content = file.readText()
            val json = convertFromMarkdown(content, chapterName)
            
            Log.d(TAG, "成功导入 $chapterName，共 ${countQuestions(json)} 道题目")
            Result.success(json)
        } catch (e: Exception) {
            Log.e(TAG, "导入题库失败", e)
            Result.failure(e)
        }
    }
    
    /**
     * 统计 JSON 中的题目数量
     */
    private fun countQuestions(json: String): Int {
        return try {
            val jsonArray = JSONArray(json)
            jsonArray.length()
        } catch (e: Exception) {
            0
        }
    }
    
    /**
     * 批量转换目录下所有文件
     * @param inputDir 输入目录（包含原始题库文件）
     * @param outputDir 输出目录（保存转换后的 JSON 文件）
     */
    fun batchConvert(inputDir: String, outputDir: String): BatchConvertResult {
        val inputFolder = File(inputDir)
        val outputFolder = File(outputDir)
        
        if (!inputFolder.exists() || !inputFolder.isDirectory) {
            return BatchConvertResult(0, 0, listOf("输入目录不存在"))
        }
        
        if (!outputFolder.exists()) {
            outputFolder.mkdirs()
        }
        
        var successCount = 0
        val errors = mutableListOf<String>()
        
        inputFolder.listFiles()?.forEach { file ->
            if (file.isFile && file.extension in listOf("txt", "md", "doc")) {
                try {
                    val chapterName = file.nameWithoutExtension
                    val content = file.readText()
                    val json = convertFromMarkdown(content, chapterName)
                    
                    val outputFile = File(outputFolder, "$chapterName.json")
                    outputFile.writeText(json)
                    
                    successCount++
                    Log.d(TAG, "转换成功: ${file.name} -> ${outputFile.name}")
                } catch (e: Exception) {
                    errors.add("转换失败 ${file.name}: ${e.message}")
                    Log.e(TAG, "转换失败 ${file.name}", e)
                }
            }
        }
        
        return BatchConvertResult(
            totalFiles = inputFolder.listFiles()?.size ?: 0,
            successCount = successCount,
            errors = errors
        )
    }
    
    /**
     * 批量转换结果
     */
    data class BatchConvertResult(
        val totalFiles: Int,
        val successCount: Int,
        val errors: List<String>
    )
    
    /**
     * 生成示例题库 JSON
     * 用于测试和演示
     */
    fun generateSampleQuestionBank(): String {
        val sampleQuestions = listOf(
            mapOf(
                "id" to "sample_1",
                "chapter" to "示例章节",
                "type" to "single_choice",
                "content" to "以下哪项是中华民族精神的核心？",
                "options" to listOf("A.勤劳勇敢", "B.自强不息", "C.爱国主义", "D.改革创新"),
                "answer" to "C",
                "explanation" to "爱国主义是中华民族精神的核心，是凝聚中华民族的强大精神力量。"
            ),
            mapOf(
                "id" to "sample_2",
                "chapter" to "示例章节",
                "type" to "single_choice",
                "content" to "中国精神的内涵包括民族精神和什么？",
                "options" to listOf("A.时代精神", "B.创新精神", "C.奋斗精神", "D.团结精神"),
                "answer" to "A",
                "explanation" to "中国精神是民族精神和时代精神的统一。"
            ),
            mapOf(
                "id" to "sample_3",
                "chapter" to "示例章节",
                "type" to "multiple_choice",
                "content" to "以下哪些属于爱国主义的内涵？（多选）",
                "options" to listOf(
                    "A.爱祖国的大好河山",
                    "B.爱自己的骨肉同胞",
                    "C.爱祖国的灿烂文化",
                    "D.爱自己的国家"
                ),
                "answer" to "ABCD",
                "explanation" to "爱国主义包括爱祖国的大好河山、爱自己的骨肉同胞、爱祖国的灿烂文化、爱自己的国家四个方面。"
            )
        )
        
        val jsonArray = JSONArray()
        sampleQuestions.forEach { q ->
            val jsonObject = JSONObject().apply {
                put("id", q["id"])
                put("chapter", q["chapter"])
                put("type", q["type"])
                put("content", q["content"])
                put("options", JSONArray(q["options"] as List<*>))
                put("answer", q["answer"])
                put("explanation", q["explanation"])
            }
            jsonArray.put(jsonObject)
        }
        
        return jsonArray.toString(2)
    }
}
