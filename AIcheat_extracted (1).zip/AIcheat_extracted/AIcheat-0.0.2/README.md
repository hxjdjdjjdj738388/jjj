---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 3045022100ccd7c5b2bddda2bf105c375e8771c9b9e6cab80a0d186b35a586e4c25fcef86302201f2ac3d37bfaea93a4f9b4c651efa355e2be4f6df8797b0a04c2be8553a8fa5e
    ReservedCode2: 3045022015b4ce745f1c812b49c6fd4229e946523d1496d76231047bda48a752a266c16e022100db047d268679ccb65b9add0a847ecf0d954451e7cf6d3a8770a9070f2250686c
---

一个使用root权限运行的快捷作业检查软件

通过截图发给ai，再将ai返回的结果显示出来

音量上控制悬浮窗显示,音量下控制截图发给ai

需要自备ai的api。

之后可能会添加更隐蔽的显示手段,比如选择题将✅显示在选项前面,答案直接显示在输入框中

不要用于作弊 不要用于作弊 不要用于作弊

软件使用造成的任何后果自己承担，本身只是一个快速的作业检查软件